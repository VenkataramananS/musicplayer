package com.musicplayer.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.musicplayer.R
import com.musicplayer.adapters.SongAdapter
import com.musicplayer.databinding.FragmentSearchBinding
import com.musicplayer.models.Song
import com.musicplayer.services.MusicService
import com.musicplayer.viewmodels.MusicViewModel
import com.musicplayer.viewmodels.PlaylistViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!

    private val musicViewModel: MusicViewModel by activityViewModels()
    private val playlistViewModel: PlaylistViewModel by viewModels()
    private lateinit var songAdapter: SongAdapter
    private var searchJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        try {
            _binding = FragmentSearchBinding.inflate(inflater, container, false)
            return binding.root
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            setupRecyclerView()
            setupSelectionBar()
            setupSearch()
            observeData()
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Failed to setup search fragment: ${e.message}")
        }
    }

    private fun setupRecyclerView() {
        songAdapter = SongAdapter(
            mutableListOf(),
            onSongClick = { song ->
                try {
                    musicViewModel.setCurrentSong(song)
                    val searchQueue = musicViewModel.searchResults.value ?: listOf(song)
                    val index = searchQueue.indexOf(song).coerceAtLeast(0)
                    startPlayback(song, ArrayList(searchQueue), index)
                } catch (e: Exception) {
                    e.printStackTrace()
                    showError("Failed to play song: ${e.message}")
                }
            },
            onSelectionChanged = { count ->
                updateSelectionBar(count)
            }
        )

        binding.searchResultsRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = songAdapter
        }
    }

    private fun startPlayback(song: Song, queue: ArrayList<Song>, index: Int) {
        val intent = Intent(requireContext(), MusicService::class.java).apply {
            action = MusicService.ACTION_PLAY
            putExtra(MusicService.EXTRA_SONG, song)
            putParcelableArrayListExtra(MusicService.EXTRA_QUEUE, queue)
            putExtra(MusicService.EXTRA_CURRENT_INDEX, index)
        }
        requireContext().startForegroundService(intent)

        val navView = requireActivity().findViewById<BottomNavigationView>(R.id.nav_view)
        navView.selectedItemId = R.id.playerFragment
    }

    private fun setupSelectionBar() {
        try {
            binding.addToPlaylistButton.setOnClickListener {
                showAddToPlaylistDialog()
            }
            binding.cancelSelectionButton.setOnClickListener {
                songAdapter.exitSelectionMode()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateSelectionBar(count: Int) {
        try {
            if (count > 0) {
                binding.selectionBar.visibility = View.VISIBLE
                binding.selectionCountText.text = "$count selected"
            } else {
                binding.selectionBar.visibility = View.GONE
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAddToPlaylistDialog() {
        try {
            val selectedSongs = songAdapter.getSelectedSongs()
            if (selectedSongs.isEmpty()) {
                showMessage("No songs selected")
                return
            }

            val playlists = playlistViewModel.allPlaylists.value
            if (playlists.isNullOrEmpty()) {
                showMessage("No playlists yet. Create one first!")
                return
            }

            val playlistNames = playlists.map { it.name }.toTypedArray()
            val songCount = selectedSongs.size

            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add $songCount song${if (songCount > 1) "s" else ""} to playlist")
                .setItems(playlistNames) { _, which ->
                    try {
                        val selectedPlaylist = playlists[which]
                        selectedSongs.forEach { song ->
                            playlistViewModel.addSongToPlaylist(selectedPlaylist.id, song.id)
                        }
                        showMessage("Added $songCount song${if (songCount > 1) "s" else ""} to ${selectedPlaylist.name}")
                        songAdapter.exitSelectionMode()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        showError("Failed to add to playlist: ${e.message}")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Failed to show playlist dialog: ${e.message}")
        }
    }

    private fun setupSearch() {
        try {
            binding.searchEditText.addTextChangedListener { text ->
                try {
                    searchJob?.cancel()
                    searchJob = lifecycleScope.launch {
                        delay(500)
                        val query = text.toString().trim()
                        if (query.isNotEmpty()) {
                            binding.emptyStateText?.visibility = View.GONE
                            musicViewModel.searchSongs(query)
                        } else {
                            songAdapter.updateSongs(emptyList())
                            binding.emptyStateText?.apply {
                                this.text = "Type to search songs"
                                visibility = View.VISIBLE
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    showError("Search error: ${e.message}")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Failed to setup search: ${e.message}")
        }
    }

    private fun observeData() {
        try {
            musicViewModel.searchResults.observe(viewLifecycleOwner) { songs ->
                try {
                    if (songs.isNotEmpty()) {
                        songAdapter.updateSongs(songs)
                        binding.emptyStateText?.visibility = View.GONE
                    } else {
                        val query = binding.searchEditText.text.toString()
                        if (query.isNotEmpty()) {
                            binding.emptyStateText?.apply {
                                text = "No results found for \"$query\""
                                visibility = View.VISIBLE
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    showError("Failed to display results: ${e.message}")
                }
            }

            musicViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
                try {
                    binding.loadingProgressBar?.visibility =
                        if (isLoading) View.VISIBLE else View.GONE
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            musicViewModel.errorMessage.observe(viewLifecycleOwner) { error ->
                try {
                    if (error.isNotEmpty()) {
                        showError(error)
                        musicViewModel.clearError()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Failed to observe data: ${e.message}")
        }
    }

    private fun showError(message: String) {
        try { Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { e.printStackTrace() }
    }

    private fun showMessage(message: String) {
        try { Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { e.printStackTrace() }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        searchJob?.cancel()
        _binding = null
    }
}