package com.musicplayer.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.musicplayer.databinding.ItemSongBinding
import com.musicplayer.models.Song
import com.musicplayer.utils.TimeFormatter

class SongAdapter(
    private val songs: MutableList<Song>,
    private val onSongClick: (Song) -> Unit,
    private val onSelectionChanged: (Int) -> Unit = {}
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val selectedSongIds = mutableSetOf<Long>()
    var isSelectionMode = false
        private set

    inner class SongViewHolder(private val binding: ItemSongBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(song: Song) {
            try {
                binding.apply {
                    songTitle.text = song.title
                    songArtist.text = song.artist
                    songDuration.text = TimeFormatter.formatMillisToTime(song.duration)

                    root.alpha = if (isSelectionMode && song.id in selectedSongIds) 0.5f else 1.0f

                    root.apply {
                        setOnClickListener {
                            if (isSelectionMode) {
                                toggleSelection(song)
                            } else {
                                onSongClick(song)
                            }
                        }
                        setOnLongClickListener {
                            if (!isSelectionMode) {
                                enterSelectionMode(song)
                            } else {
                                toggleSelection(song)
                            }
                            true
                        }
                        isClickable = true
                        isFocusable = true
                        isLongClickable = true
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun enterSelectionMode(song: Song) {
        isSelectionMode = true
        selectedSongIds.add(song.id)
        notifyDataSetChanged()
        onSelectionChanged(selectedSongIds.size)
    }

    fun exitSelectionMode() {
        isSelectionMode = false
        selectedSongIds.clear()
        notifyDataSetChanged()
        onSelectionChanged(0)
    }

    fun toggleSelection(song: Song) {
        if (selectedSongIds.contains(song.id)) {
            selectedSongIds.remove(song.id)
        } else {
            selectedSongIds.add(song.id)
        }
        if (selectedSongIds.isEmpty()) {
            exitSelectionMode()
        } else {
            notifyDataSetChanged()
            onSelectionChanged(selectedSongIds.size)
        }
    }

    fun getSelectedSongs(): List<Song> {
        return songs.filter { it.id in selectedSongIds }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        try {
            val binding = ItemSongBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return SongViewHolder(binding)
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        }
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        try {
            if (position >= 0 && position < songs.size) {
                holder.bind(songs[position])
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount() = songs.size

    fun updateSongs(newSongs: List<Song>) {
        try {
            val diffCallback = SongDiffCallback(songs, newSongs)
            val diffResult = DiffUtil.calculateDiff(diffCallback)
            songs.clear()
            songs.addAll(newSongs)
            diffResult.dispatchUpdatesTo(this)
        } catch (e: Exception) {
            e.printStackTrace()
            songs.clear()
            songs.addAll(newSongs)
            notifyDataSetChanged()
        }
    }

    private class SongDiffCallback(
        private val oldList: List<Song>,
        private val newList: List<Song>
    ) : DiffUtil.Callback() {
        override fun getOldListSize() = oldList.size
        override fun getNewListSize() = newList.size
        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition].id == newList[newItemPosition].id
        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
            oldList[oldItemPosition] == newList[newItemPosition]
    }
}