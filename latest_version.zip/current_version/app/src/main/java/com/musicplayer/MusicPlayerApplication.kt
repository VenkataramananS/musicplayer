package com.musicplayer

import android.app.Application
import com.musicplayer.database.MusicDatabase
import com.musicplayer.utils.PermissionHelper

class MusicPlayerApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        try {
            initializeDatabase()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initializeDatabase() {
        try {
            val database = MusicDatabase.getDatabase(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}