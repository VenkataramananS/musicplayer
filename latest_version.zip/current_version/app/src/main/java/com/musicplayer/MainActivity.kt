package com.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.musicplayer.databinding.ActivityMainBinding
import com.musicplayer.viewmodels.MusicViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val musicViewModel: MusicViewModel by viewModels()
    private val PERMISSION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
            setupNavigation()
            requestPermissionsIfNeeded()
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Failed to initialize app: ${e.message}")
        }
    }

    private fun setupNavigation() {
        try {
            val navController = findNavController(R.id.nav_host_fragment)
            val navView: BottomNavigationView = binding.navView
            navView.setupWithNavController(navController)
        } catch (e: Exception) {
            e.printStackTrace()
            showError("Navigation setup failed: ${e.message}")
        }
    }

    private fun requestPermissionsIfNeeded() {
        try {
            val permissionsToRequest = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (permissionsToRequest.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), PERMISSION_REQUEST_CODE)
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            if (requestCode == PERMISSION_REQUEST_CODE) {
                val denied = permissions.zip(grantResults.toTypedArray())
                    .filter { it.second != PackageManager.PERMISSION_GRANTED }
                    .map { it.first }
                if (denied.isEmpty()) {
                    showMessage("All permissions granted")
                } else {
                    if (Manifest.permission.READ_MEDIA_AUDIO in denied)
                        showError("Audio permission denied. App needs access to play music.")
                    if (Manifest.permission.POST_NOTIFICATIONS in denied)
                        showMessage("Notification permission denied. Playback controls won't show in notifications.")
                }

                // Re-scan songs after audio permission is granted
                if (Manifest.permission.READ_MEDIA_AUDIO in permissions) {
                    val index = permissions.indexOf(Manifest.permission.READ_MEDIA_AUDIO)
                    if (index >= 0 && grantResults[index] == PackageManager.PERMISSION_GRANTED) {
                        musicViewModel.loadSongsFromDevice()
                    }
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun showError(message: String) {
        try { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { e.printStackTrace() }
    }
    private fun showMessage(message: String) {
        try { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { e.printStackTrace() }
    }
}