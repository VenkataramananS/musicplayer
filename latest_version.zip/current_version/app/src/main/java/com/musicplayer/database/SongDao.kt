package com.musicplayer.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.musicplayer.models.Song

@Dao
interface SongDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: Song)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSongs(songs: List<Song>)

    @Query("SELECT * FROM songs ORDER BY title ASC")
    fun getAllSongs(): LiveData<List<Song>>

    @Query("SELECT * FROM songs ORDER BY artist ASC")
    fun getAllSongsByArtist(): LiveData<List<Song>>

    @Query("SELECT * FROM songs ORDER BY dateAdded DESC")
    fun getAllSongsByDate(): LiveData<List<Song>>

    @Query("SELECT * FROM songs WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%'")
    fun searchSongs(query: String): LiveData<List<Song>>

    @Delete
    suspend fun deleteSong(song: Song)

    @Query("SELECT * FROM songs WHERE id = :songId")
    fun getSongById(songId: Long): LiveData<Song>
}