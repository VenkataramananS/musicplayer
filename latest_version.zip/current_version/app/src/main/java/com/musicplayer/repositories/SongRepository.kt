package com.musicplayer.repositories

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import androidx.lifecycle.LiveData
import com.musicplayer.database.SongDao
import com.musicplayer.models.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SongRepository(private val songDao: SongDao, private val context: Context) {

    fun getAllSongs(): LiveData<List<Song>> = songDao.getAllSongs()

    fun getAllSongsByArtist(): LiveData<List<Song>> = songDao.getAllSongsByArtist()

    fun getAllSongsByDate(): LiveData<List<Song>> = songDao.getAllSongsByDate()

    fun searchSongs(query: String): LiveData<List<Song>> = songDao.searchSongs(query)

    suspend fun loadSongsFromDevice() {
        withContext(Dispatchers.IO) {
            try {
                val songs = mutableListOf<Song>()
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_ADDED
                )

                val cursor = context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    null
                )

                cursor?.use { c ->
                    val idColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val dateAddedColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                    while (c.moveToNext()) {
                        val id = c.getLong(idColumn)
                        val title = c.getString(titleColumn) ?: "Unknown"
                        val artist = c.getString(artistColumn) ?: "Unknown Artist"
                        val album = c.getString(albumColumn) ?: "Unknown Album"
                        val duration = c.getLong(durationColumn)
                        val dateAdded = c.getLong(dateAddedColumn) * 1000L

                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                        ).toString()

                        val song = Song(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            duration = duration,
                            path = contentUri,
                            dateAdded = dateAdded
                        )
                        songs.add(song)
                    }
                }

                if (songs.isNotEmpty()) {
                    songDao.insertAllSongs(songs)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}