# 🎵 Music Player

A modern offline music player for Android 14+ with a Spotify-inspired UI, full dark theme support, and smooth playback experience.

## Features

### Playback
- **Tap-to-Play**: Tap any song to instantly start playback and navigate to the player
- **Background Playback**: Continue playing with screen off via foreground service with media notification
- **Playback Controls**: Play, pause, next, previous, shuffle, repeat (off/all/one)
- **Seekbar**: Scrub to any position in a song
- **Sleep Timer**: Auto-stop playback after 5, 10, 15, or 30 minutes
- **Content URI Playback**: Uses modern MediaStore content URIs instead of deprecated file paths

### Library
- **Auto-Scan**: Automatically discovers all audio files on device via MediaStore
- **Search**: Debounced real-time search across titles and artists
- **Sort Options**: Sort by title, artist, or date added (sourced from MediaStore)
- **Multi-Select**: Long-press to enter selection mode, tap to toggle, batch add to playlist

### Playlists & Queue
- **Playlist Management**: Create, delete, and organize playlists
- **Batch Add to Playlist**: Select multiple songs and add to any playlist
- **Queue Management**: View the upcoming queue
- **Drag-to-Reorder**: Drag handle to reorder songs in the queue via ItemTouchHelper

### UI/UX
- **Splash Screen**: Animated logo fade-in on launch (always light theme)
- **Spotify-Inspired Design**: Clean, flat UI with green accent (#1DB954), album art placeholders, modern navigation
- **Dark Theme**: Automatic DayNight switching — dark palette (#121212) follows system setting
- **Light Theme Default**: White background with green accents as the primary look
- **Bottom Navigation**: Home, Search, Playlists, Player tabs with color state selector

## Architecture

**MVVM + Repository Pattern**

```
┌─────────────────────────────────────────────────┐
│                     UI Layer                     │
│  SplashActivity → MainActivity                   │
│  ├── HomeFragment        (song list + sort)      │
│  ├── SearchFragment      (real-time search)      │
│  ├── PlaylistFragment    (playlist CRUD)         │
│  └── PlayerFragment      (now playing + queue)   │
│       └── Binds to MusicService                  │
├─────────────────────────────────────────────────┤
│                  ViewModel Layer                  │
│  MusicViewModel (shared via activityViewModels)  │
│  ├── allSongs: LiveData<List<Song>>              │
│  ├── searchResults: LiveData<List<Song>>         │
│  ├── currentSong: LiveData<Song>                 │
│  └── sortOption: LiveData<String>                │
│  PlaylistViewModel (fragment-scoped)             │
│  └── allPlaylists: LiveData<List<Playlist>>      │
├─────────────────────────────────────────────────┤
│                 Repository Layer                  │
│  SongRepository                                  │
│  ├── getAllSongs/ByArtist/ByDate (Room LiveData) │
│  └── loadSongsFromDevice (MediaStore → Room)     │
│  PlaylistRepository                              │
│  └── CRUD operations for playlists               │
├─────────────────────────────────────────────────┤
│                  Data Layer                       │
│  Room Database (MusicDatabase v3)                │
│  ├── SongDao         (songs table)               │
│  └── PlaylistDao     (playlists + playlist_songs)│
│  MediaStore API      (device audio scanning)     │
├─────────────────────────────────────────────────┤
│                 Service Layer                     │
│  MusicService (Foreground Service)               │
│  ├── MediaPlayer     (audio playback)            │
│  ├── Queue management (next/prev/shuffle/repeat) │
│  ├── WakeLock        (screen-off playback)       │
│  └── Notification    (media controls)            │
└─────────────────────────────────────────────────┘
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| `activityViewModels()` for MusicViewModel | Shared state across all fragments — tap in Home, see it in Player |
| Content URIs over file paths | `MediaStore.Audio.Media.DATA` is deprecated; content URIs are the modern standard |
| `fallbackToDestructiveMigration()` | App re-scans all songs on startup, so DB wipe on schema change is safe |
| Room + LiveData for song list | Instant display from cache on launch, background refresh from MediaStore |
| Foreground service with `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Required on Android 14+ for media playback services |
| DayNight theme with `values-night/` resources | Drawables auto-adapt via color references — no `drawable-night/` needed |

## Project Structure

```
app/src/main/
├── java/com/musicplayer/
│   ├── SplashActivity.kt          # Animated splash screen
│   ├── MainActivity.kt            # Navigation host + permission handling
│   ├── MusicPlayerApplication.kt  # App-level database init
│   ├── ErrorHandler.kt            # Global error utilities
│   ├── adapters/
│   │   ├── SongAdapter.kt         # Song list + multi-select
│   │   ├── PlaylistAdapter.kt     # Playlist list
│   │   └── QueueAdapter.kt        # Queue with drag handle
│   ├── database/
│   │   ├── MusicDatabase.kt       # Room DB (v3)
│   │   ├── SongDao.kt             # Song queries
│   │   └── PlaylistDao.kt         # Playlist queries
│   ├── fragments/
│   │   ├── HomeFragment.kt        # All songs + sort + auto-play
│   │   ├── SearchFragment.kt      # Search + auto-play
│   │   ├── PlaylistFragment.kt    # Playlist management
│   │   └── PlayerFragment.kt      # Now playing + queue + controls
│   ├── models/
│   │   ├── Song.kt                # Song entity (Parcelable)
│   │   ├── Playlist.kt            # Playlist entity
│   │   └── PlaylistSong.kt        # Many-to-many join
│   ├── repositories/
│   │   ├── SongRepository.kt      # MediaStore scan + Room access
│   │   └── PlaylistRepository.kt  # Playlist CRUD
│   ├── services/
│   │   └── MusicService.kt        # MediaPlayer foreground service
│   ├── utils/
│   │   ├── Constants.kt           # Sort constants
│   │   ├── MediaPlayerHelper.kt   # MediaPlayer utilities
│   │   ├── PermissionHelper.kt    # Permission checks
│   │   └── TimeFormatter.kt       # Duration formatting
│   └── viewmodels/
│       ├── MusicViewModel.kt      # Shared music state
│       └── PlaylistViewModel.kt   # Playlist state
├── res/
│   ├── layout/                    # 9 layouts (splash, activity, 4 fragments, 3 items)
│   ├── drawable/                  # Modern flat drawables + new_logo
│   ├── values/                    # Light theme colors, strings, dimens
│   ├── values-night/              # Dark theme colors + theme overrides
│   ├── color/                     # nav_item_color selector
│   ├── navigation/                # nav_graph.xml (4 destinations)
│   └── menu/                      # bottom_nav_menu.xml
└── AndroidManifest.xml
```

## Tech Stack

| Component | Version |
|-----------|---------|
| Kotlin | 1.9.22 |
| Min SDK | 34 (Android 14) |
| Target/Compile SDK | 34 |
| Java | 17 |
| Room | 2.6.1 |
| Navigation | 2.7.7 |
| Lifecycle | 2.7.0 |
| Material Components | 1.11.0 |
| Coroutines | 1.7.3 |

## Permissions

| Permission | Purpose |
|-----------|---------|
| `READ_MEDIA_AUDIO` | Access audio files on device |
| `POST_NOTIFICATIONS` | Show playback notification |
| `FOREGROUND_SERVICE` | Background audio playback |
| `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Required service type on Android 14+ |
| `WAKE_LOCK` | Keep CPU awake during playback |

## Build & Run

1. Open project in Android Studio Hedgehog+
2. Add your app logo as `res/drawable/new_logo.png`
3. Generate app icon: **File → New → Image Asset** → select `new_logo.png`
4. Connect an Android 14+ device or emulator
5. Run the app — grant audio permission when prompted

## License

This project is for personal/educational use.